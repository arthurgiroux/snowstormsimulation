Snow storm simulation
===================

Introduction to computer graphics project
See projectproposal.pdf for more information
